# MusicInfoSCR::Plugin.pm by Michael Herger 2005-2008, parts by kdf Dec 2003, fcm4711 Oct 2005, triode Sept 2006
#
# This code is derived from code with the following copyright message:
#
# SliMP3 Server Copyright (C) 2001 Sean Adams, Slim Devices Inc.
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.
#
# Changelog
# 4.4.11 - improve compatibility with 7.9's volatile tracks: they're not really remote streams
# 4.4.10 - add change I must have added a while ago, but never committed to SVN. Make it not fail without a track.
# 4.4.9- fix compatibility with UEML 10.0
#      - another approach at fixing the disappearing formats issue: do not initialize plugin unless this is a supported player
# 4.4.8- fix date/time display in powered off mode when there's nothing in the playlist
#      - always use uppercase ID for custom tags
#      - initialize custom formats whenever we're called and they don't exist yet
# 4.4.7- fix button press behaviour when "Jump back" is disabled (see https://bugs.slimdevices.com/show_bug.cgi?id=15366)
# 4.4.6- remove that workaround again. It's fixed in SBS
# 4.4.5- add workaround for issue in SBS title parser when unsupported tags for remote tracks are being requested
#        see https://bugs.slimdevices.com/show_bug.cgi?id=14872
# 4.4.3- fix alarm saver custom font settings
# 4.4.2- fix compatibility with older versions...
# 4.4.1- fix compatibility with Slim::Utils::Alarm changes
# 4.4.0- add Off / Alarm screensaver mode
#      - add ALARM (next alarm time within 24h) and BELL (alarm clock symbol if alarm within 24h) formats
# 4.3.8- improve compatibility with 7.4/TinySC
# 4.3.7- fix tag parsing not to match tag names which are only part of the full name (eg. TITLE in WHATEVERTITLE)
# 4.3.6- access client object to know repeat/shuffle state, not the prefs
# 4.3.5- Argh... fix the "monster overlaying title" in custom font size mode
# 4.3.4- better fix for the custom format behaviour when player is disconnected: always getClient($client->id)
#        instead of trying to keep the client current
# 4.3.3- fix PLAYTIME_ALWAYS in playlist mode - show displayed track's duration, not currently playing track
#      - need to delete custom formats when player is disconnected/reconnected, 
#        or the $client-object passed to the format handler won't work any more
#      - improve behaviour with remote streams which offer no data at all
# 4.3.2- fix x/y display -> needs to be X_Y, as / is considered a tag separator
# 4.3  - rewrite custom format handling
#      - add PLAYTIME_ALWAYS, PLAYTIME_REMAINING
#      - use configuration as shown on Boom box as default layout
#      - rename PLAYTIME_PROGRESS to NOWPLAYING_DEFAULT
# 4.2  - improved remote stream support
#      - code cleanup, using $client->pluginData() instead of own hash
# 4.1  - add sleep buttons
# 4.00 - SlimServer 7.0 compliance
#      - WYSIWYG editor for the settings
#      - rely on server side caching of contents, don't cache locally (and therefore remove whitelist as well)
#      - code cleanup
# 3.05 - add "X/Y" format
# 3.04 - add BUFFERBAR format
# 3.03 - add new BUFFER format
# 3.02 - add new NOTESYMBOL format
# 3.01 - add new KBPS format (thanks schiegl http://forums.slimdevices.com/showpost.php?p=162830&postcount=4)
# 3.00 - renamed to "Music Information Screen"
#      - improve icon handling (use font files)
#      - add alternative volume, playlist and extended text screen - thanks to Triode
#      - new tags PLAYTIME_PROGRESS, SONGTIME, DATE et al.
#      - move settings to their own page
#      - add format whitelist: entries will _always_ be updated, never cached
#      - add option to fix a display's font size
#      - give up on slimserver <6.5: most new features are 6.5 only
#      - add a reset button, fix initialization
# 2.44- improved internet radio station handling
# 2.43- improved 6.5 compatibility
# 2.42- fix an issue with playtime
#     - only display second screen when in extended text mode
# 2.41- optionally disable visualizer
#     - fix some ugly copy/paste stuff
# 2.40- add support for Transporter dual screen
#     - _really_ emove that support for 3rd party plugins... (see 2.30)
# 2.34- added Dutch translation - thanks a lot Patrick!
# 2.33- remove progress bar from PLAYTIME in double size font mode
# 2.32- q'n'd fix for the progressbar in double size font crash...
# 2.31- use standard text for screensaver activation
# 2.30- remove that support again, as addFormat() should do the same...
# 2.20- add support for third party plugins (thanks a lot Erland Isaksson!)
# 2.10- re-unite versions for 6.2.x and 6.5
#     - try to better handle button presses when jumping to the playlist
# 2.09- add LONGDATE/SHORTDATE variables - thanks Urs Zurbuchen
# 2.07- add Italian translation - thanks Riccardo!
# 2.05- fix an issue when radio stations would display a blank value for tags like "TITLE (ARTIST)"
# 2.02- prepare plugin for use with slimserver 6.5
# 2.01- fixed some issues with too aggressive caching and added one pixel before the icons
# 2.0 - add icons for shuffle and repeat modes - thanks to Felix Müller
#     - remove 6.1 stuff
# 1.9 - prepare for new %lines hash and prefs methods (>=6.2)
# 1.85- James Craig added a fullscreen progress bar - thanks, James!
# 1.8 - added support for new scrolling code in 6.1
# 1.73- fixed display change after scrolling of second line
# 1.72- fixed PLAYTIME display for streams that display 11329320:33:39...
# 1.71- fixed CURRTIME display (don't cache the current time...)
# 1.7 - removed manual update of line2 (only with >=6.1)
# 1.61- don't translate format strings (eg. X_OF_Y)
# 1.6 - improved PLAYTIME progressbar with different displays
# 1.51- improved online stream handling
# 1.5 - fixes for SlimServer v6.0
#     - added display cache for much lower cpu load
# 1.4 - added "CURRENTTIME", "PLAYLIST"
#     - added option to display playlist name if ALBUM/ARTIST is not available (streams)
# 1.3 - added general "FORMAT (X_OF_Y)"
#     - some cosmetics with PLAYTIME (put a space before progressbar, if reasonable)
# 1.2 - fixed progressbar in PLAYTIME
#     - added "X out of Y" style
#     - added french translation
# 1.1 - handle empty playlists, stopped, paused
#     - added jump back configuration: jump back to where you left or go to playlist
#     - added second value (right) for double line
# 1.0 - initial release

package Plugins::MusicInfoSCR::Plugin;

use strict;

use Plugins::MusicInfoSCR::Settings;
use Plugins::MusicInfoSCR::Info;
use Plugins::MusicInfoSCR::Web;
use Slim::Utils::Strings qw (string);
use Slim::Utils::Prefs;

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.musicinfoscr',
	'defaultLevel' => 'ERROR',
	'description'  => 'PLUGIN_MUSICINFO',
});

use vars qw($VERSION);

my $prefs = preferences('plugin.musicinfo');

sub getDisplayName {
	return 'PLUGIN_MUSICINFO';
}

sub initPlugin {
	$VERSION = __PACKAGE__->_pluginDataFor('version');
	
	Slim::Control::Request::subscribe(
		sub {
			my $client = $_[0]->client();

			# do not initialize plugin unless this is a supported player
			return unless $client && !$client->display->isa('Slim::Display::NoDisplay');

			Plugins::MusicInfoSCR::Info::init($client);
			Plugins::MusicInfoSCR::Settings::updateClientSettings($client);
		},
		[['client'], ['new']]
	);

	if (!$::noweb) {
		Plugins::MusicInfoSCR::Settings->new();
		

		my $done = 0;
		if (Slim::Utils::Versions::compareVersions($::VERSION, '7.4') >= 0) {
			eval {
				Slim::Web::Pages->addPageFunction("plugins/MusicInfoSCR/settings/preview.html", 
					\&Plugins::MusicInfoSCR::Web::handlePreview);
				$done = 1;
			}
		}
	
		if (!$done) {
			Slim::Web::HTTP::addPageFunction("plugins/MusicInfoSCR/settings/preview.html", 
				\&Plugins::MusicInfoSCR::Web::handlePreview);
		}
	}	

	Slim::Buttons::Common::addSaver( 'SCREENSAVER.musicinfo',
		getScreensaverMusicInfo(),
		\&setScreensaverMusicInfoMode,
		\&leaveScreensaverMusicInfoMode,
		'PLUGIN_MUSICINFO');
	
	preferences('server')->setChange(sub {
		my ($name, $value, $client) = @_;
		
		if ($value eq 'SCREENSAVER.musicinfo' && !$prefs->client($client)->get('plugin_musicinfo_alarm')) {
			$prefs->client($client)->set('plugin_musicinfo_alarm', 1);
		}
		elsif ($value ne 'SCREENSAVER.musicinfo') {
			$prefs->client($client)->set('plugin_musicinfo_alarm', 0);
		}
		
	}, 'alarmsaver');
	

	Slim::Music::TitleFormatter::addFormat('SONGTIME', \&Plugins::MusicInfoSCR::Info::getSongTime);
	Slim::Music::TitleFormatter::addFormat('KBPS', \&Plugins::MusicInfoSCR::Info::getKBPS);
	Slim::Music::TitleFormatter::addFormat('NOW_PLAYING', sub { return string('PLAYING'); });
	Slim::Music::TitleFormatter::addFormat('PLAYING', sub { return string('PLAYING'); });
}

# entirely stolen from Triode's demo code :-)
sub volumeLines {
	my $client = shift;
	my $vol = shift;

	# custom character names are not defined as entire screen components use the volume font
	# uses font file volumeSB2.2 for volume graphic and text:
	#  chr 1 - space before start of graphic bar
	#  chr 2 - 'dB' icon
	#  chr 3 - infinity character
	#  chr 65 - 65+32 - graphic bars
	#  numeric characters are used as normal from this font

	if (!defined $vol->{value} && $client->modeParam('valueRef')) {
		$vol = ${$client->modeParam('valueRef')};
	}

	my $dbVal = $vol ? sprintf('%.1f', -abs(($vol / 2) - 50)) : '-' . chr(3);
	$dbVal .= chr(2);

	my $bar = chr(1);

	for (my $i = 0; $i <= 32; $i++) {
		last if ($i > $vol/3);
		$bar .= chr($i+65);
	}

	return {
		'line'    => [ $client->string('VOLUME'), $bar ],
		'overlay' => [ undef, $dbVal ],
		'fonts' => {
			'graphic-320x32' => { 'line' => [ 'standard.1', 'MIScrVolumeSB2.2' ], 'overlay' => [ undef, 'MIScrVolumeSB2.2' ] },
		}
	};
}

my %screensaverMusicInfoFunctions = (
	'done' => sub {
		my ( $client, $funct, $functarg ) = @_;
		Slim::Buttons::Common::popMode($client);
		if (not $prefs->client($client)->get('plugin_musicinfo_jump_back')) {
			if (Slim::Buttons::Common::mode($client) eq 'playlist') {
				Slim::Buttons::Common::popMode($client);
			}
			Slim::Buttons::Common::pushMode( $client, 'playlist' );
		}
		$client->update();

		# pass along ir code to new mode if requested
		if ( defined $functarg && $functarg eq 'passback' ) {
			Slim::Hardware::IR::resendButton($client);
		}
	}
);

sub getScreensaverMusicInfo {
	return \%screensaverMusicInfoFunctions;
}

sub leaveScreensaverMusicInfoMode {
	my $client = shift;

	$client->modeParam('visu', $client->pluginData('oldVisualizer'));
	$client->update({'screen2' => {}});
}

sub setScreensaverMusicInfoMode {
	my $client = shift;

	# setting this param will call client->update() frequently
	$client->modeParam('modeUpdateInterval', 1);

	# optionally disable visualizer
	$client->pluginData('oldVisualizer', $client->modeParam('visu'));
	$client->modeParam('visu', [0]) if ($prefs->client($client)->get('plugin_musicinfo_disable_visualizer'));

	if ($client->display->isa('Slim::Display::Transporter')) {
		$client->modeParam('screen2', 'MusicInfoSCR');
		$client->lines( \&screensaverMusicInfoLinesDual );
	}
	else {
		$client->lines( \&screensaverMusicInfoLines );
	}
}

sub playlistMusicInfoLines {
	my ($client, $args) = @_;

	return if (!defined $client);

	my $infoLines;

	my $tot = Slim::Player::Playlist::count($client);

	if ($tot < 1) {
		$infoLines = {
			'line' => [ $client->string('NOW_PLAYING'), $client->string('NOTHING') ]
		};
	}

	else {
		my $songIndex = Slim::Buttons::Playlist::browseplaylistindex($client);

		if ( $songIndex >= $tot ) {
			$songIndex = Slim::Buttons::Playlist::browseplaylistindex($client, $tot - 1);
		}

		# see whether we copy the settings from the screensaver or not
		$infoLines = Plugins::MusicInfoSCR::Info::getMusicInfoLines(
			$client, 
			$args,
			($prefs->client($client)->get('plugin_musicinfo_playlist') == 2) ? '_P' : '',
			$songIndex
		);

		$infoLines->{'screen2'} = Plugins::MusicInfoSCR::Info::getMusicInfoLines(
			$client, 
			$args,
			($prefs->client($client)->get('plugin_musicinfo_playlist') == 2) ? '_PX' : '_X',
			$songIndex
		) if ($client->display->showExtendedText());
	}

	return $infoLines;
}

sub extendedTextModeLines {
	my ($client, $args) = @_;

	# see whether we copy the settings from the screensaver or not
	my $screen = screensaverMusicInfoLines($client, $args, 
		$prefs->client($client)->get('plugin_musicinfo_extended') == 2 ? '_2X' : '');
	
	return { 'screen2' => $screen }; 
}

sub screensaverMusicInfoLinesDual {
	my ($client, $args) = @_;
	
	my $infoLines = screensaverMusicInfoLines($client, $args);
	$infoLines->{'screen2'} = screensaverMusicInfoLines($client, $args, '_X') if ($client->display->showExtendedText());
	return $infoLines;
}

sub screensaverMusicInfoLines {
	my ($client, $args, $screen) = @_;
	return Plugins::MusicInfoSCR::Info::getMusicInfoLines($client, $args, $screen);
}

sub getMusicInfoSCRCustomItems {
	my $customFormats = {
		
		'BUFFER' => {
			'cb' => \&Plugins::MusicInfoSCR::Info::getBufferFullness,
			'cache' => 1	# cache value for a second
		},
		
		'NOTESYMBOL' => {
			'cb' => sub {
				return $_[0]->symbols('notesymbol');
			},
			'cache' => -1	# let the display do the caching
		},
		
		'PLAYLIST' => {
			'cb' => sub {
				my $client = $_[0];
				if (my $string = $client->currentPlaylist()) {
					return Slim::Music::Info::standardTitle($client, $string);
				}
			},
			'cache' => -1
		}, 

		'PLAYTIME_ALWAYS' => {
			'cb' => sub {
				my $client = $_[0];
				my $songIndex = $client->pluginData('songIndex');
				my $song = $client->pluginData('song');

				return defined $songIndex && $songIndex >= 0 ? Plugins::MusicInfoSCR::Info::getSongTime($song) : $client->textSongTime(); 
			},
			'cache' => 0.5
		}, 

		'PLAYTIME_REMAINING' => {
			'cb' => sub {
				my $client = $_[0];
				my $songIndex = $client->pluginData('songIndex');
				my $song = $client->pluginData('song');

				return defined $songIndex && $songIndex >= 0 ? Plugins::MusicInfoSCR::Info::getSongTime($song) : $client->textSongTime(1); 
			},
			'cache' => 0.5
		}, 

		'X_OF_Y' => {
			'cb' => sub {
				my $client = $_[0];
				my $songIndex = $client->pluginData('songIndex');
				
				return sprintf("%d %s %d", 
						(defined $songIndex && $songIndex >= 0 ? $songIndex : Slim::Player::Source::playingSongIndex($client)) + 1, 
						$client->string('OUT_OF'), Slim::Player::Playlist::count($client));
			},
			'cache' => 0
		},

		'X_Y' => {
			'cb' => sub {
				my $client = $_[0];
				my $songIndex = $client->pluginData('songIndex');
				
				return sprintf("%d/%d", 
						(defined $songIndex && $songIndex >= 0 ? $songIndex : Slim::Player::Source::playingSongIndex($client)) + 1, 
						Slim::Player::Playlist::count($client));
			},
			'cache' => 0
		},

		'BELL' => {
			'cb' => sub {
				my $client = $_[0];
				
				my $currentAlarm = Slim::Utils::Alarm->getCurrentAlarm($client);
				my $nextAlarm = Slim::Utils::Alarm->getNextAlarm($client);
			
				# show alarm symbol if active or set for next 24 hours
				if (defined $currentAlarm || ( defined $nextAlarm && ($nextAlarm->nextDue - time < 86400) )) {
					if (defined $currentAlarm && $currentAlarm->snoozeActive) {
						return $client->symbols('sleep');
					} else {
						return $client->symbols('bell');
					}
				}
			},
			'cache' => 0
		},

		'ALARM' => {
			'cb' => sub {
				my $client = $_[0];
		
				my $currentAlarm = Slim::Utils::Alarm->getCurrentAlarm($client);
				my $nextAlarm = Slim::Utils::Alarm->getNextAlarm($client);

				# Include the next alarm time in the overlay if there's room
#				if (defined $currentAlarm || ( defined $nextAlarm && ($nextAlarm->nextDue - time < 86400) )) {
				if ( defined $nextAlarm && ($nextAlarm->nextDue - time < 86400) ) {
					# Remove seconds from alarm time
					my $timeStr = Slim::Utils::DateTime::timeF($nextAlarm->time % 86400, $prefs->client($client)->get('timeFormat'), 1);
					$timeStr =~ s/(\d?\d\D\d\d)\D\d\d/$1/;
					return $timeStr;
				}
			},
			'cache' => 0
		},
	};
	
	foreach my $tag (@Plugins::MusicInfoSCR::Info::remoteTags) {
		$customFormats->{'_MIS_REMOTE_' . $tag} = {
			'cb' => \&Plugins::MusicInfoSCR::Info::getRemoteData,
			'cache' => 1
		}
	}
	
	return $customFormats;
}

sub _pluginDataFor {
	my $class = shift;
	my $key   = shift;

	my $pluginData = Slim::Utils::PluginManager->dataForPlugin($class);

	if ($pluginData && ref($pluginData) && $pluginData->{$key}) {
		return $pluginData->{$key};
	}

	return undef;
}

1;
