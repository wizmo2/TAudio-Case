# Plugins::MusicInfoSCR::Info.pm by mh 2006/7
#
# This code is derived from code with the following copyright message:
#
# SliMP3 Server Copyright (C) 2001 Sean Adams, Slim Devices Inc.
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.

use strict;

package Plugins::MusicInfoSCR::Info;

use Time::HiRes;
use Scalar::Util qw(blessed);

use Slim::Utils::Strings qw (string);
use Slim::Utils::Log;
use Slim::Utils::Prefs;

my $prefs = preferences('plugin.musicinfo');
my $serverPrefs = preferences('server');

my $log = logger('plugin.musicinfoscr');

my $customItems;
our @remoteTags  = qw(TITLE ARTIST ALBUM DURATION REPLAY_GAIN TYPE BITRATE);

sub init {
	my $client = shift;

	$customItems = Plugins::MusicInfoSCR::Settings::getCustomItems($client) if $client;

	Plugins::MusicInfoSCR::Settings::initClientSettings($client);
}

sub initDisplayCache {
	my $client = shift;

	$log->debug('Clearing MIS font cache');

	$client->pluginData('postfix', undef);
	$client->pluginData('graphical', 0);
	$client->pluginData('model', '');
	$client->pluginData('font', undef);
}

sub initDisplayModes {
	my $client = shift;
	my $postfix = shift;

	return if (
		defined $client->pluginData('postfix')
		&& $client->pluginData('postfix') eq $postfix
		&& $client->pluginData('model')
		&& $client->pluginData('graphical')
		&& ( 
			($client->pluginData('font') && keys %{$client->pluginData('font')})
			|| $client->pluginData('model') ne 'SB2' 
			|| $prefs->client($client)->get('plugin_musicinfo_size' . $postfix)
		)
	);

	$log->debug('Initializing MIS font cache');
	
	if ($client->isa('Slim::Player::Squeezebox2')) {
		$client->pluginData('postfix', $postfix);
		$client->pluginData('model', 'SB2');
		$client->pluginData('graphical', 1);
		$client->pluginData('font',
			($prefs->client($client)->get('plugin_musicinfo_size' . $postfix))
				? {}
				: { $client->display->vfdmodel() => {
						'line' => [ 
							$prefs->client($client)->get("plugin_musicinfo_lineA$postfix" . "_size"), 
							$prefs->client($client)->get("plugin_musicinfo_line_dbl$postfix" . "_size"), 
							$prefs->client($client)->get("plugin_musicinfo_lineB$postfix" . "_size")
						],
						'center' => [
							$prefs->client($client)->get("plugin_musicinfo_centerA$postfix" . "_size"), 
							$prefs->client($client)->get("plugin_musicinfo_center_dbl$postfix" . "_size"), 
							$prefs->client($client)->get("plugin_musicinfo_centerB$postfix" . "_size")
						],
						'overlay' => [
							$prefs->client($client)->get("plugin_musicinfo_overlayA$postfix" . "_size"),
							$prefs->client($client)->get("plugin_musicinfo_overlay_dbl$postfix" . "_size"),
							$prefs->client($client)->get("plugin_musicinfo_overlayB$postfix" . "_size")
						],
					}
				}
		);
	}
	elsif ($client->isa('Slim::Player::Squeezebox') && $client->display->isa('Slim::Display::SqueezeboxG')) {
		$client->pluginData('model', 'SBG');
		$client->pluginData('graphical', 1);
	}
}

sub getMusicInfoLines {
	my ($client, $args, $postfix, $songIndex) = @_;

	my $mode = Slim::Buttons::Common::mode($client) || '';

	$customItems = Plugins::MusicInfoSCR::Settings::getCustomItems($client) unless $customItems && $customItems != {};

	$postfix ||= '';
	
	if ($mode =~ /^OFF\./) {
		if ($postfix eq '_X') {
			$postfix = '_OFFX';
		}
		else {
			$postfix = '_OFF';
		}
	}
	
	elsif ($mode eq Slim::Utils::Alarm->alarmScreensaver($client)
		&& Slim::Utils::Alarm->getCurrentAlarm($client)
		&& $prefs->client($client)->get("plugin_musicinfo_alarm") == 2) {
	
		if ($postfix eq '_X') {
			$postfix = '_AX';
		}
		else {
			$postfix = '_A';
		}
	}

	my ( $line1, $center1, $overlay1, $line2, $center2, $overlay2, $line3, $center3, $overlay3 ) 
			= ('', '', '', '', '', '', '', '', '');

	my $song;

	my $nowPlaying = (!defined $songIndex || Slim::Player::Source::playingSongIndex($client) == $songIndex);

	# single line mode: when large font, and font not overwritten
	my $singleLine = ($client->linesPerScreen() == 1 && $prefs->client($client)->get("plugin_musicinfo_size$postfix"));

	initDisplayModes($client, $postfix);

	# if there's nothing playing just display... nothing!
	if (Slim::Player::Playlist::count($client) < 1 && $postfix !~ /(?:_X|_OFF)/) {
		$line1 = string('NOW_PLAYING');
		$line2 = $line3 = string('NOTHING');
	}
	else {
		$song = Slim::Player::Playlist::song($client, $songIndex);

		# cache remote data if available
		$client->pluginData('remoteData', undef);
		if ($song && Slim::Music::Info::isRemoteURL($song->url)) {
	
			my $handler = Slim::Player::ProtocolHandlers->handlerForURL($song->url);
	
			if ( $handler && $handler->can('getMetadataFor') ) {
	
				$client->pluginData('remoteData', $handler->getMetadataFor( $client, $song->url ));
			}
		}

		$client->pluginData('songIndex', defined $songIndex ? $songIndex : -1);
		$client->pluginData('song', $song);

		if ($singleLine) {
			$line2 = getFormatString($client, "plugin_musicinfo_line_dbl$postfix" || "plugin_musicinfo_lineB$postfix");
			$center2 = getFormatString($client, "plugin_musicinfo_center_dbl$postfix");
			$overlay2 = getFormatString($client, "plugin_musicinfo_overlay_dbl$postfix");
		}
		else {
			$line1 = getFormatString($client, "plugin_musicinfo_lineA$postfix");
			$center1 = getFormatString($client, "plugin_musicinfo_centerA$postfix");
			$overlay1 = getFormatString($client, "plugin_musicinfo_overlayA$postfix");
			
			if ($client->isa('Slim::Player::Squeezebox2')) {
				$line2 = getFormatString($client, "plugin_musicinfo_lineB$postfix");
				$center2 = getFormatString($client, "plugin_musicinfo_centerB$postfix");
				$overlay2 = getFormatString($client, "plugin_musicinfo_overlayB$postfix");

				if (!$prefs->client($client)->get('plugin_musicinfo_size' . $postfix)) {
					$line3 = $line2;
					$center3 = $center2;
					$overlay3 = $overlay2;

					$line2 = getFormatString($client, "plugin_musicinfo_line_dbl$postfix");
					$center2 = getFormatString($client, "plugin_musicinfo_center_dbl$postfix");
					$overlay2 = getFormatString($client, "plugin_musicinfo_overlay_dbl$postfix");					
				}
			}
			else {
				# pre-SB2 players can't handle three lines - use third as second...
				$line2 = getFormatString($client, "plugin_musicinfo_lineB$postfix");
				$center2 = getFormatString($client, "plugin_musicinfo_centerB$postfix");
				$overlay2 = getFormatString($client, "plugin_musicinfo_overlayB$postfix");
			}

			# if there's no information for the first line, display the playlistname or "now playing..." 
			# (eg. for author information with online streaming etc.)
			if (!$line1 && !$postfix && $prefs->client($client)->get("plugin_musicinfo_lineA$postfix")) {
				$line1 = getFormatString($client, 'PLAYLIST', $song, $songIndex);
				$line1 = string('NOW_PLAYING') if ($line1 eq $line2 || not $line1);
			}
			
			if (!$line2 && !$postfix && $prefs->client($client)->get('plugin_musicinfo_size') && $song) {
				$line2 = Slim::Music::Info::getCurrentTitle($client, $song->url);
			}
		}
	}

	# some special information (on first display only, not in full size mode)
	if ($postfix !~ /(?:OFF|X)$/ && !$singleLine) {
		# handle special modes... 
		if (Slim::Player::Source::playmode($client) eq 'pause' && $nowPlaying) {
			$line1 = $client->string('PAUSED') . ($line1 ? ' - ' . $line1 : '');
		}
		elsif (Slim::Player::Source::playmode($client) eq 'stop' && $nowPlaying) {
			$line1 = $client->string('STOPPED') . ($line1 ? ' - ' . $line1 : '');
		}

		# Repeat/Shuffle icons - right; don't display icons in full size mode
		if (my $showIcons = $prefs->client($client)->get('plugin_musicinfo_show_icons')) {
			$overlay1 = buttonIcons($client, $showIcons, $overlay1) if ($showIcons =~ /^TOPRIGHT[2]*$/);
		}

		# sleep icons - right
		if (my $showIcons = $prefs->client($client)->get('plugin_musicinfo_show_sleep')) {
			$overlay1 = sleepIcons($client, $showIcons, $overlay1) if ($showIcons =~ /^TOPRIGHT[23]*$/);
		}

		# status icons - right; don't display icons in full size mode
		if (my $showIcons = $prefs->client($client)->get('plugin_musicinfo_show_status')) {
			$overlay1 = wifiIcons($client, $showIcons, $overlay1) if ($showIcons =~ /^TOPRIGHT*$/);
			$overlay1 = batteryIcons($client, $showIcons, $overlay1) if ($showIcons =~ /^TOPRIGHT*$/);
		}
	}

	# PLAYTIME stuff...
	$line1 = getPlayTime($client, $line1, $overlay1, 1, $song, $nowPlaying);
	$line2 = getPlayTime($client, $line2, $overlay2, 2, $song, $nowPlaying);
	$line3 = getPlayTime($client, $line3, $overlay3, 2, $song, $nowPlaying);

	# Repeat/Shuffle icons - left
	if ($postfix !~ /X$/ && !$singleLine) {
		if (my $showIcons = $prefs->client($client)->get('plugin_musicinfo_show_icons')) {
			$line1 = buttonIcons($client, $showIcons, $line1) if ($showIcons =~ /^TOPLEFT[2]*$/);
		}

		# sleep icons - right
		if (my $showIcons = $prefs->client($client)->get('plugin_musicinfo_show_sleep')) {
			$line1 = sleepIcons($client, $showIcons, $line1) if ($showIcons =~ /^TOPLEFT[23]*$/);
		}

		# status icons - right
		if (my $showIcons = $prefs->client($client)->get('plugin_musicinfo_show_status')) {
			$line1 = wifiIcons($client, $showIcons, $line1) if ($showIcons =~ /^TOPLEFT*$/);
			$line1 = batteryIcons($client, $showIcons, $line1) if ($showIcons =~ /^TOPLEFT*$/);
		}
	}
	
	$overlay1 = getPlayTime($client, $overlay1, $line1, 1, $song, $nowPlaying);
	$overlay2 = getPlayTime($client, $overlay2, $line2, 2, $song, $nowPlaying);
	$overlay3 = getPlayTime($client, $overlay3, $line3, 2, $song, $nowPlaying);

	return {
		'line' => [ $line1, $line2, $line3 ],
		'center' => [ $center1 || undef, $center2 || undef, $center3 || undef ],
		'overlay' => [ $overlay1, $overlay2, $overlay3 ],
		'fonts' => $client->pluginData('font')
	};
}

sub getFormatString {
	my ($client, $formatString) = @_;
	
	# get the real format definition if we're passed a pref identifier
	$formatString = $prefs->client($client)->get($formatString) if ($formatString =~ /^plugin_musicinfo_/);

	return '' if $formatString =~ /^(?:NOTHING|)$/ || !$client;

	my $song = $client->pluginData('song');
	my $songIndex = $client->pluginData('songIndex');

	my $formattedString = $formatString;
	my $titleOnly;

	my $albumOrArtist = ($formatString =~ /(ALBUM|ARTIST)/i);
			
	if ($song && Slim::Music::Info::isRemoteURL($song->url)) {

		if ( $client->pluginData('remoteData') ) {

			foreach my $tag (@remoteTags) {
				$formattedString =~ s/\b$tag\b/_MIS_REMOTE_$tag/g;
			}

		} 
		else {
			$titleOnly = Slim::Music::Info::getCurrentTitle($client, $song->url);
			$formattedString =~ s/\bTITLE\b/_MIS_TITLE/g
		}

	}

	my $id = '_MIS_CUSTOM_' . uc($client->id);
	$id =~ s/://g;

	for my $tag (keys %{$customItems}) {
		$formattedString =~ s/\b$tag\b/$id$tag/g;		
	}

	my $meta;
	if ( $song && (my $handler = Slim::Player::ProtocolHandlers->handlerForURL($song->url)) ) {
		$meta = $handler->getMetadataFor( $client, $song->url ) if $handler->can('getMetadataFor');
	}

	$formattedString = Slim::Music::Info::displayText($client, $song, $formattedString, $meta) || '';
	
	# let's hard code some formats commonly used in power off mode. This would otherwise fail if nothing is in the playlist
	if (!$formattedString && $formatString =~ /^(?:CURRTIME|SHORTDATE|LONGDATE)$/) {
		my $formatter = Slim::Music::TitleFormatter::_parseFormat($formatString);
		if ($formatter) {
			$formattedString = $formatter->();
		}
	}

	$formattedString =~ s/_MIS_TITLE/$titleOnly/g;

	# remove our custom tags in case they haven't returned anything useful
	foreach my $tag (@remoteTags) {
		$formattedString =~ s/\b_MIS_REMOTE_$tag\b//g;
	}

	# one more special case... ARTIST with a radio stream results in... nothing. Replace by TITLE		
	if ((!$formattedString) && ($formatString =~ /TITLE/) && $titleOnly) {
		$formattedString = $titleOnly;
	}
	
	$formattedString =~ s/(?:\(\)|\[\]|\{\})//g;
	$formattedString =~ s/-\s$//;
	
	# if ARTIST/ALBUM etc. is empty, replace them by some "Now playing..."
	if ($albumOrArtist) {
		my $tmpFormattedString = $formattedString;
		my $noArtist = $client->string('NO_ARTIST');
		my $noAlbum = $client->string('NO_ALBUM');
		$tmpFormattedString =~ s/($noAlbum|$noArtist|No Album|No Artist)//ig;
		$tmpFormattedString =~ s/\W//g;

		if (! $tmpFormattedString) {
			
			my $string;
			
			# Fallback for streams: display playlist name (if available)
			if ($client->currentPlaylist() && $prefs->client($client)->get('plugin_musicinfo_stream_fallback') && ($string = Slim::Music::Info::standardTitle($client, $client->currentPlaylist()))) {
				$log->is_debug && $log->debug("empty string being replaced by playlist name");
				$formattedString = $string;
			}
			else {
				$log->is_debug && $log->debug("MusicInfoSCR: there seems to be nothing left...\n");
				$formattedString = '';
			}
		}
	}
	
	$formattedString =~ s/NOTHING//g;

	return $formattedString;
}

sub getCustomTagData {
	my ($client, $song, $tag) = @_;

	$client = Slim::Player::Client::getClient($client->id) || return;

	my $string;
	my $cache = $client->pluginData('cache');
	my $cachedItem = $cache->{$tag};
	
	if ((defined $customItems->{$tag}->{'cache'} && !(defined $cachedItem->{'timeout'} && $cachedItem->{'value'}))
		|| (defined $customItems->{$tag}->{'cache'} && $cachedItem->{'timeout'} && $cachedItem->{'timeout'} <= Time::HiRes::time())
		|| ($song && (not defined $customItems->{$tag}->{'cache'}) && $cachedItem->{'key'} ne Slim::Music::Info::getCurrentTitle($client, $song->url) . $song->url)) {

		$string = eval { &{$customItems->{$tag}->{'cb'}}($client, $song, $tag) };
				
		$log->error("Problem executing callback: $@") if $@;
			
		$cachedItem->{'value'} = $string;
				
		# store some caching triggers
		if (defined $customItems->{$tag}->{'cache'}) {
			$cachedItem->{'timeout'} = Time::HiRes::time() + $customItems->{$tag}->{'cache'};
		}
		elsif ($song) {
			$cachedItem->{'key'} = Slim::Music::Info::getCurrentTitle($client, $song->url) . $song->url;
		}
			
		$cache->{$tag} = $cachedItem;
		$client->pluginData('cache', $cache);			
	}
			
	else {
		$string = $cachedItem->{'value'};
	}

	return $string;	
}

sub getPlayTime {
	my ($client, $part1, $part2, $line, $song, $nowPlaying) = @_;

	return $part1 unless ($part1 =~ /(?:NOWPLAYING_DEFAULT|PLAYTIME|PROGRESSBAR)/);
	
	# in playlist mode don't display playtime & co., but only SONGTIME
	if (!$nowPlaying) {
		# don't display a progress bar in playlist mode
		$part1 =~ s/PROGRESSBAR//g;
		
		# in playlist mode always display SONGTIME only, when PLAYTIME is defined 
		my $songtime = getSongTime($song);
		$part1 =~ s/\bPLAYTIME\b/$songtime/g;
	}
	
	my %parts;

	if ($part1 && ($part1 =~ /(?:NOWPLAYING_DEFAULT|PLAYTIME)/)) {
		my $withoutTag = $part1;

		# if we want the progressbar, do some width calculation
		if ($part1 =~ /NOWPLAYING_DEFAULT/) {
			$withoutTag =~ s/NOWPLAYING_DEFAULT//;

			if ($line == 2 && $client->measureText(' ', 1)) {
				# pad string if left part is smaller than half the display size
				if ($client->measureText($part2, $line) < ($client->displayWidth()/2)) {
					$part2 = pack('A' . int(($client->displayWidth() / 1.7) / $client->measureText(' ', 1)), ' ');
				}
				else {
					$part2 = pack('A' . int($client->measureText("$part2  X", 2) / $client->measureText(' ', 1)), ' ');
				}
			}
			else {
				$part2 .= ' ';
			}
		}

		$parts{'line'}[0] = $part2 . $withoutTag;

		$client->nowPlayingModeLines( \%parts );

		# remove the progress bar if we only want the playtime and playtime is displayed (not buffer)
		if ($parts{'overlay'} && $part1 !~ /NOWPLAYING_DEFAULT/ && $parts{'overlay'}[0] =~ /\d{1,2}\:\d{1,2}/) {
			# remove anything that's not part of a usual time display...
			$parts{'overlay'}[0] =~ s/[^\-\d\:]//g;
		}

		$part1 =~ s/NOWPLAYING_DEFAULT|PLAYTIME/$parts{'overlay'}[0]/g if $parts{'overlay'};
		$part1 =~ s/NOWPLAYING_DEFAULT|PLAYTIME//g;
	}

	# use match so we get just the progress bar even if paused/stopped
	if ($part1 and ($part1 =~ /PROGRESSBAR/)) {
		if (Slim::Player::Source::playingSongDuration($client)) {
			# below copied from nowPlayingModeLines, otherwise would have to reset the now playing mode
			my $withoutTag = $part1;
			$withoutTag =~ s/PROGRESSBAR//;
			$part2 .= ' ' . $withoutTag if ($part2);
		
			my $fractioncomplete = Slim::Player::Source::progress($client);
			my $barlen = $client->displayWidth() - $client->measureText($part2, $line);
			
			# in single line mode (double sized font), half the length - progressBar does not seem to be aware of this
			$barlen /= 2 if (not $client->measureText(' ', 1));
			$part2 = $client->symbols($client->progressBar($barlen, $fractioncomplete));
			$part1 =~ s/PROGRESSBAR/$part2/;
		} else {
			# don't print anything if there's no duration
			$part1 =~ s/PROGRESSBAR//;
		}
	}
	
	# remove trailing/leading blanks
	$part1 =~ s/^\s*(\S*)\s$/$1/;

	return $part1;
}

# mostly taken from Slim::Player::Player::nowPlayingModeLines
sub getBufferFullness {
	my ($client, $more) = @_;
	my ($url);

	if (blessed($more)) {
		$url = $more->url;	
	}

	my $fractioncomplete = 0;

	$fractioncomplete = $client->usage();
	my $songtime = int($fractioncomplete * 100 + 0.5)."%";
	
	# for remote streams where we know the bitrate, 
	# show the number of seconds of audio in the buffer instead of a percentage
	if ( (!$url || Slim::Music::Info::isRemoteURL($url)) && $client->streamingSong->streamUrl !~ /^tmp:/ ) {
		
		my $decodeBuffer;
		
		# Display decode buffer as seconds if we know the bitrate, otherwise show KB
		my $bitrate = $url ? Slim::Music::Info::getBitrate($url) : 0;
		if ( $bitrate > 0 ) {
			$decodeBuffer = sprintf( "%.1f", $client->bufferFullness() / ( int($bitrate / 8) ) );
		}
		else {
			$decodeBuffer = sprintf( "%d KB", $client->bufferFullness() / 1024 );
		}

		if ( $client->isa('Slim::Player::Squeezebox2') ) {
			# Only show output buffer status on SB2 and higher
			my $outputBuffer = $client->outputBufferFullness() / (44100 * 8);
			$songtime  = ' ' . sprintf "%s / %.1f", $decodeBuffer, $outputBuffer;
			$songtime .= ' ' . $client->string('SECONDS') unless $client->isa('Slim::Player::Boom');
		}
		else {
			$songtime  = ' ' . sprintf "%s", $decodeBuffer;
			$songtime .= ' ' . $client->string('SECONDS');
		}
	}
	
	return $songtime;
}

sub getSongTime {
	my $song = $_[0];

	my $songduration;
	if (ref $song && ref $song eq 'HASH') {
		$songduration = $song->{secs} || $song->{duration};
	}
	
	$songduration ||= Slim::Music::Info::getDuration($song);
	
	my $hrs = int($songduration / (60 * 60));
	my $min = int(($songduration - $hrs * 60 * 60) / 60);
	my $sec = $songduration - ($hrs * 60 * 60 + $min * 60);
	
	if ($hrs) {
		$songduration = sprintf("%d:%02d:%02d", $hrs, $min, $sec);
	} else {
		$songduration = sprintf("%02d:%02d", $min, $sec);
	}

	return $songduration;
}	

sub getKBPS {
	my $song = $_[0];

	my $bitrate = Slim::Music::Info::getBitrate($song);
	my $kbps = int($bitrate / 1000);

	return $kbps . string('KBPS');
}

sub getRemoteData {
	my ($client, $song, $tag) = @_;

	if ($client->pluginData('remoteData')) {
		$tag =~ s/_MIS_REMOTE_//g;
		return $client->pluginData('remoteData')->{lc($tag)} || '';
	}
	
	return '';
}

sub buttonIcons {
	my ($client, $position, $line) = @_;
	
	return '' unless $client->pluginData('graphical');

	my $shuffleState = Slim::Player::Playlist::shuffle($client);
	my $repeatState = Slim::Player::Playlist::repeat($client);

	if (($shuffleState != $client->pluginData('shuffle'))
	 || ($repeatState != $client->pluginData('repeat'))
	 || ($line ne $client->pluginData('line'))
	 || ($position ne $client->pluginData('position'))) {

		# TOP*2 means always display the icon, while TOP* only 
		# does when some shuffle/repeat mode is set
		if ($shuffleState || ($position =~ /TOP(LEFT|RIGHT)2/)) {
			$line .= addIcon($client, chr(4 + $shuffleState));
		}

		if ($repeatState || ($position =~ /TOP(LEFT|RIGHT)2/)) {
			$line .= addIcon($client, chr(1 + $repeatState));
		}

		$client->pluginData('repeat', $repeatState);
		$client->pluginData('shuffle', $shuffleState);
		$client->pluginData('position', $position);
		$client->pluginData('line', $line);
	}

	return $line;
}

sub sleepIcons {
	my ($client, $position, $line) = @_;

	my $remaining = $client->sleepTime;

	return $line unless ($client->isa('Slim::Player::Squeezebox2') && $remaining);

	$remaining = $remaining - time();
	my @sleepChoices = (90, 60, 45, 30, 15, 10, 5);
	my $sleepState = 0;

	# find the next value for the sleep timer
	for ($sleepState = $#sleepChoices; $sleepState >= 0; $sleepState--) {

		if ( $remaining <= $sleepChoices[$sleepState]*60 ) {
			last;
		}
	}

	# TOP*2 means show animated icon
	if ($position =~ /TOP(LEFT|RIGHT)2/ && $sleepState <= $#sleepChoices) {

		$line .= addIcon($client, chr(8 + ($sleepState*2) + ($remaining%2)));
	}

	elsif ($position =~ /TOP(LEFT|RIGHT)$/ || $sleepState == $#sleepChoices) {

		$line .= addIcon($client, chr(7));
	}

	return $line;
}

sub batteryIcons {
	my ($client, $position, $line) = @_;
	
	my $value = $client->voltage || $client->voltage > 0 || $client->voltage < 20 ?
		$client->voltage : undef;

	# abort for unsupported devices and voltage values
	return $line unless ($client->isa('Slim::Player::Squeezebox2') && $value);

	my @batteryChoices = $value < 6 ?
	 (3.9, 3.8, 3.7, 3.6, 3.5, 3.4, 3.3, 0) : # single cell
     (12.6, 12.4, 12.2, 12.0, 11.8, 11.6, 11.4, 0); # tripple cell
	my $batteryState = 0;

	# find the next value for the battery
	for ($batteryState = 0; $batteryState <= $#batteryChoices; $batteryState++) {
		if ( $value > $batteryChoices[$batteryState] ) {
			$line .= addIcon($client, chr(36 + $batteryState));
			last;
		}
	}
	$log->info("voltage '$value' icon '$batteryState'");

	return $line;
}

sub wifiIcons {
	my ($client, $position, $line) = @_;

	my $value = $client->signalStrength ? $client->signalStrength : undef;

	return $line unless ($client->isa('Slim::Player::Squeezebox2') && $value);

	my @wifiChoices = (90, 75, 60, 45, 20, 0);
	my $wifiState = 0;

	# find the next value for the signal strength
	for ($wifiState = 0; $wifiState <= $#wifiChoices; $wifiState++) {
		if ( $value > $wifiChoices[$wifiState] ) {
			$line .= addIcon($client, chr(30 + $wifiState));
			last;
		}
	}
	# $log->info("SignalStrength '$value' icon '$wifiState'");

	return $line;
}

sub addIcon {
	my ($client, $symbol) = @_;
	my $display = $client->display;
	
	# issues with chars 10(a), 27(1b),28(1c),29(1d)
	return $display->symbols('tight') . $display->symbols('font')
		. 'MIScrIcons' . $client->pluginData('model') . '.1' .$display->symbols('/font') 
		. chr(0) . $symbol . $display->symbols('defaultfont') . $display->symbols('/tight');	
}

1;
